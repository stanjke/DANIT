If you need help or want to suggest anything, contact me at discord.

https://discord.gg/gDct7m5cnc